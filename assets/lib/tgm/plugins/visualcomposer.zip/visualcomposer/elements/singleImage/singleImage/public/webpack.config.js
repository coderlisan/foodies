module.exports = {
  entry: {
    singleImage: ['./src/singleImage.js']
  },
  output: {
    filename: '[name].min.js'
  }
}
