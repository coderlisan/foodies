module.exports = {
  entry: {
    faqToggle: ['./js/faqToggle.js']
  },
  output: {
    filename: 'dist/[name].min.js'
  }
}
